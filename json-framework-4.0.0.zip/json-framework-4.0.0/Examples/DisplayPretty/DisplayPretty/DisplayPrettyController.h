//
//  DisplayPrettyController.h
//  DisplayPretty
//
//  Created by Stig Brautaset on 25/05/2011.
//  Copyright 2011 Stig Brautaset. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DisplayPrettyController : NSObject
@end
